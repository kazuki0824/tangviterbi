module top(input wire core_clk,mem_clk,resetn,output wire activity);
reg[255:0] stimulus=256'h8128643212344321;
always @(posedge mem_clk)if(!resetn)stimulus<=256'h8128643212344321;
else stimulus<={stimulus[254:0],stimulus[255]^stimulus[253]^stimulus[250]^stimulus[245]};
wire ready,valid,wr;wire[20:0] addr;wire[255:0] data;wire[31:0] mask;wire[15:0] level;
dual_burst_fifo #(.DEPTH(256)) fifo(mem_clk,resetn,stimulus[0],ready,stimulus[1],stimulus[22:2],stimulus,stimulus[95:64],
valid,stimulus[23],wr,addr,data,mask,level);
assign activity=^{ready,valid,wr,addr,data,mask,level};
endmodule
