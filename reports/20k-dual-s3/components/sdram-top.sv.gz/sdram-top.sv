module top(input wire clk,resetn,output wire activity);
 reg[255:0] lfsr=256'h8128643212344321;
 always @(posedge clk)if(!resetn)lfsr<=256'h8128643212344321;
 else lfsr<={lfsr[254:0],lfsr[255]^lfsr[253]^lfsr[250]^lfsr[245]};
wire ready,valid,init,fault,cke,oe;wire[255:0] data;wire[2:0] cmd;
 wire[1:0] bank;wire[10:0] addr;wire[3:0] mask;wire[31:0] dout;
 dual_sdram_burst mem(clk,resetn,lfsr[0],ready,lfsr[1],{lfsr[20:3],3'd0},lfsr,lfsr[95:64],
 valid,lfsr[2],data,init,fault,cmd,bank,addr,cke,mask,oe,dout,lfsr[63:32]);
 assign activity=^{ready,valid,data,init,fault,cmd,bank,addr,cke,mask,oe,dout};
endmodule
