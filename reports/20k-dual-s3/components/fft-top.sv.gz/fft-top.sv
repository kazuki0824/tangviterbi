module top(input wire clk,resetn,output wire activity);
 reg[255:0] lfsr=256'h8128643212344321;
 always @(posedge clk)if(!resetn)lfsr<=256'h8128643212344321;
 else lfsr<={lfsr[254:0],lfsr[255]^lfsr[253]^lfsr[250]^lfsr[245]};
wire lr,busy,done,rv,overflow;wire[31:0] rd;wire[5:0] phase;
 wire signed[17:0] wr,wi;wire ci,cv,cf;wire[31:0] cd;
 wire mv;wire[20:0] ma;wire[9:0] mi;wire[12:0] mp;wire[2:0] mk,ml;wire[7:0] mc;
 dual_fft_burst_map mapper(lfsr[3:0],lfsr[4],lfsr[5],{lfsr[49:32],3'd0},lfsr[68:64],lfsr[79:72],lfsr[82:80],mv,ma,mi,mp,mk,ml,mc);
 wire[12:0] wphase=busy ? {1'b0,phase,6'd0} : lfsr[12:0];
 dual_fft_twiddle tw(clk,wphase,wr,wi);
 dual_fft_tile tile(clk,resetn,lfsr[130:128],lfsr[133:131],lfsr[1],lfsr[2],lfsr[3],lr,lfsr[13:4],lfsr[63:32],lfsr[14],busy,done,
 lfsr[15],lfsr[25:16],rv,rd,phase,wr,wi,overflow);
 dual_fft_cross cross_unit(clk,resetn,!busy&&lfsr[3],ci,lfsr[95:80],lfsr[127:112],wr,wi,cv,lfsr[14],cd,cf);
 assign activity=^{lr,busy,done,rv,overflow,rd,ci,cv,cf,cd,mv,ma,mi,mp,mk,ml,mc};
endmodule
