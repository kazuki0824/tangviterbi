module top(input wire clk,resetn,output wire activity);
 reg[255:0] lfsr=256'h8128643212344321;
 always @(posedge clk)if(!resetn)lfsr<=256'h8128643212344321;
 else lfsr<={lfsr[254:0],lfsr[255]^lfsr[253]^lfsr[250]^lfsr[245]};
wire[2:0] ready,grant;wire v,first,last,fail;wire[1:0] owner;wire[7:0] data;
 dual_shared_rs rs(clk,resetn,lfsr[2:0],lfsr[5:3],lfsr[63:40],ready,grant,v,first,last,fail,owner,data);
 assign activity=^{ready,grant,v,first,last,fail,owner,data};
endmodule
