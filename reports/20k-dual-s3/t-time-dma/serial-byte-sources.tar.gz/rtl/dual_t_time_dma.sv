// Time deinterleaver after frequency deinterleaving/demapping. Each carrier is
// six unchanged 8-bit LLRs, segment-major then carrier-major then bit order.
// Fixed legal mode/layer parameters; runtime TMCC reconfiguration is outside.
// One finite symbol RAM holds both incoming and reordered outgoing bytes.
// A new symbol exchanges its bytes with the previous result: the old byte must
// be consumed before its location is reused. drain_only emits the final result.
// Upstream must retain a complete symbol and honor ready (not raw unstoppably
// arriving RF). No claim of a complete capture/demapper/decoder pipeline.
module dual_t_time_dma #(
 parameter integer MODE=1,S0=3,I0=4,S1=3,I1=8,S2=7,I2=16,
 parameter [22:0] BASE=0
)(input wire clk,resetn,
 input wire start_valid,output wire start_ready,input wire drain_only,
 input wire in_valid,output wire in_ready,input wire[7:0] in_data,
 output wire out_valid,input wire out_ready,output wire[7:0] out_data,
 output wire out_last,output reg out_settled,
 output reg result_ready,output reg symbol_done,output wire busy,output wire fault,
 output wire req_valid,input wire req_ready,output wire req_write,
 output wire[20:0] req_address,output wire[255:0] req_data,output wire[31:0] req_dqm,
 input wire rsp_valid,output wire rsp_ready,input wire[255:0] rsp_data);
 function integer max2(input integer a,b);max2=a>b?a:b;endfunction
 function integer minpos(input integer a,b);
  minpos=a==0?b:b==0?a:a<b?a:b;
 endfunction
 localparam R=1<<(MODE-1),N=13*96*R*6,AW=$clog2(N),DEPTH=1<<AW;
 localparam MAXI=max2(S0?I0:0,max2(S1?I1:0,S2?I2:0));
 localparam MIN_I=minpos(S0?I0:0,minpos(S1?I1:0,S2?I2:0));
 localparam STEP=MIN_I?MIN_I:1,MAXD=95*MAXI,GMAX=MAXD/STEP,GN=GMAX+1;
 localparam IDLE=0,PRIME=1,SWAP=2,PLAN=3,META=4,LAUNCH=5,ACTIVE=6,FINISH=7;
 reg[2:0] state;
 reg draining,old_sent,old_valid;reg[AW-1:0] position;
 reg[10:0] processed;reg[8:0] group_id;
 reg[9:0] feed_position,return_position;reg feed_valid;
 reg[79:0] plans[0:GN-1],meta_q;
 reg[22:0] cursors[0:GN-1],cursor_q;
 reg[7:0] symbol_ram[0:DEPTH-1],ram_q;
 wire[9:0] length=meta_q[9:0];wire[22:0] span=meta_q[32:10],base=meta_q[55:33];
 wire[2:0] active_layers=meta_q[58:56];
 wire[22:0] offset=processed==0?23'd0:cursor_q;
 wire[10:0] delay_symbols=group_id*STEP;
 function integer legal_i(input integer v);
  legal_i=v==0||v==4/R||v==8/R||v==16/R;
 endfunction
 integer g,d,sz,ptr,a,c0,c1,c2;
 initial begin
  if(MODE<1||MODE>3||S0<0||S1<0||S2<0||S0+S1+S2!=13||
     !legal_i(I0)||!legal_i(I1)||!legal_i(I2)||BASE[4:0]!=0)
   $fatal(1,"invalid fixed T configuration");
  ptr=BASE;plans[0]=0;
  for(g=1;g<GN;g=g+1)begin
   d=g*STEP;a=0;sz=0;c0=0;c1=0;c2=0;
   if(S0 && I0 && d%I0==0 && d/I0<=95)begin a=a|1;sz=sz+S0*R*6;c0=(77*(95-d/I0))%96;end
   if(S1 && I1 && d%I1==0 && d/I1<=95)begin a=a|2;sz=sz+S1*R*6;c1=(77*(95-d/I1))%96;end
   if(S2 && I2 && d%I2==0 && d/I2<=95)begin a=a|4;sz=sz+S2*R*6;c2=(77*(95-d/I2))%96;end
   plans[g]={7'(c2),7'(c1),7'(c0),3'(a),23'(ptr),23'(d*sz),10'(sz)};
   ptr=ptr+((d*sz+31)/32)*32;
  end
  if(ptr>5690880)$fatal(1,"T rings overlap S reservation");
 end
 // Position within a merged delay group -> original segment/carrier/bit slot.
 // 77 is the inverse of 5 modulo 96; repeated carrier blocks share a delay.
 function [AW-1:0] natural_address(input [9:0] index);
  integer p,segment_base,carrier;
  begin
   p=index;segment_base=0;carrier=meta_q[65:59];
   if(!(active_layers[0] && p<S0*R*6))begin
    if(active_layers[0])p=p-S0*R*6;
    segment_base=S0;carrier=meta_q[72:66];
    if(!(active_layers[1] && p<S1*R*6))begin
     if(active_layers[1])p=p-S1*R*6;
     segment_base=S0+S1;carrier=meta_q[79:73];
    end
   end
   natural_address=(segment_base+p/(R*6))*(96*R*6)+(p/6%R)*576+carrier*6+p%6;
  end
 endfunction
 wire vi_ready,vo_valid,vdone,vfault,vector_ready;
 wire[7:0] vo_data;wire[20:0] logical_word;
 assign start_ready=state==IDLE;
 assign busy=state!=IDLE;assign fault=vfault;
 assign out_valid=state==SWAP && result_ready && old_valid && !old_sent;
 assign out_data=ram_q;assign out_last=out_valid && position==N-1;
 wire old_taken=out_valid&&out_ready;
 assign in_ready=state==SWAP && !draining && (!result_ready||old_sent||old_taken);
 wire new_taken=in_valid&&in_ready;
 wire advance=state==SWAP && (draining?old_taken:new_taken);
 wire feed_fetch=state==ACTIVE && feed_position<length && (!feed_valid||vi_ready);
 wire swap_fetch=state==PRIME || (advance && result_ready && position!=N-1);
 always @(posedge clk)begin
  if(state==PLAN)begin meta_q<=plans[group_id];cursor_q<=cursors[group_id];end
  if(feed_fetch)ram_q<=symbol_ram[natural_address(feed_position)];
  else if(swap_fetch)ram_q<=symbol_ram[state==PRIME?{AW{1'b0}}:position+1'b1];
  if(new_taken)symbol_ram[position]<=in_data;
  else if(state==ACTIVE && vo_valid)
   symbol_ram[natural_address(return_position)]<=processed<delay_symbols?8'd0:vo_data;
  if(state==ACTIVE && vdone)cursors[group_id]<=offset+length>=span?23'd0:offset+length;
 end
 dual_vector_exchange exchange(clk,resetn,state==LAUNCH,vector_ready,base+offset,{6'd0,length},
  feed_valid,vi_ready,ram_q,vo_valid,1'b1,vo_data,vdone,vfault,
  req_valid,req_ready,req_write,logical_word,req_data,req_dqm,rsp_valid,rsp_ready,rsp_data);
 // The exchange operates in compact logical byte space, including BL8 cuts at
 // vector/page boundaries. Map each burst separately into banks 1..3.
 wire[12:0] page=logical_word[20:8];
 wire[10:0] row=page/3;wire[1:0] bank=page%3+1;
 assign req_address={row,bank,logical_word[7:0]};
 always @(posedge clk)begin
  if(!resetn)begin
   state<=IDLE;draining<=0;old_sent<=0;old_valid<=0;position<=0;
   processed<=0;group_id<=0;feed_position<=0;return_position<=0;feed_valid<=0;
   result_ready<=0;symbol_done<=0;out_settled<=0;
  end else begin
   symbol_done<=0;
   case(state)
    IDLE:if(start_valid)begin
     position<=0;old_sent<=0;old_valid<=0;draining<=drain_only;
     if(drain_only&&!result_ready)symbol_done<=1;
     else state<=result_ready?PRIME:SWAP;
    end
    PRIME:begin old_valid<=1;state<=SWAP;end
    SWAP:begin
     if(old_taken)old_sent<=1;
     if(advance)begin
      old_sent<=0;
      if(position==N-1)begin
       result_ready<=0;old_valid<=0;
       if(draining)begin state<=IDLE;symbol_done<=1;end
       else if(GMAX==0)state<=FINISH;
       else begin group_id<=1;state<=PLAN;end
      end else position<=position+1'b1;
     end
    end
    PLAN:state<=META;
    META:begin
     feed_position<=0;return_position<=0;feed_valid<=0;
     if(length!=0)state<=LAUNCH;
     else if(group_id==GMAX)state<=FINISH;
     else begin group_id<=group_id+1'b1;state<=PLAN;end
    end
    LAUNCH:if(vector_ready)state<=ACTIVE;
    ACTIVE:begin
     if(feed_valid&&vi_ready)feed_valid<=0;
     if(feed_fetch)begin feed_valid<=1;feed_position<=feed_position+1'b1;end
     if(vo_valid)return_position<=return_position+1'b1;
     if(vdone)begin
      feed_valid<=0;
      if(group_id==GMAX)state<=FINISH;
      else begin group_id<=group_id+1'b1;state<=PLAN;end
     end
    end
    FINISH:begin
     result_ready<=1;out_settled<=processed>=MAXD;symbol_done<=1;
     if(processed<MAXD)processed<=processed+1'b1;
     state<=IDLE;
    end
   endcase
  end
 end
endmodule
