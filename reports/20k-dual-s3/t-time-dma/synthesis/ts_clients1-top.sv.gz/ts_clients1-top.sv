module top(input wire core_clk,mem_clk,resetn,output wire activity);
reg[255:0] stimulus=256'h8128643212344321;
always @(posedge mem_clk)if(!resetn)stimulus<=256'h8128643212344321;
else stimulus<={stimulus[254:0],stimulus[255]^stimulus[253]^stimulus[250]^stimulus[245]};
wire tsready,tir,tov,tlast,tsettled,tresult,tdone,tbusy,tfault;wire[31:0] tod;wire[7:0] sout;wire clast,slast,sfault;wire[1:0] spending;wire[3:0] sowners;wire busy,done,ffault,clip,tr,trv,sr,srv,init,mfault,cke,oe;
wire[255:0] td,sd;wire[2:0] cmd;wire[1:0] bank;wire[10:0] addr;wire[3:0] dqm;wire[31:0] dout;wire[15:0] level;
dual_fft_ts_memory #(.INIT_CYCLES(27000),.MODE(1),.I0(4),.I1(8),.I2(16)) mem(core_clk,mem_clk,resetn,stimulus[0],stimulus[4:1],21'd0,21'd8192,21'd16384,
busy,done,ffault,clip,stimulus[5],tr,stimulus[6],{stimulus[24:7],3'd0},stimulus,trv,stimulus[25],td,
init,mfault,cmd,bank,addr,cke,dqm,oe,dout,stimulus[63:32],stimulus[95:64],level,
stimulus[26],sr,stimulus[34:27],srv,stimulus[46],sout,clast,slast,sfault,spending,sowners,stimulus[47],tsready,stimulus[48],stimulus[49],tir,stimulus[81:50],tov,stimulus[58],tod,tlast,tsettled,tresult,tdone,tbusy,tfault);
assign activity=^{tsready,tir,tov,tlast,tsettled,tresult,tdone,tbusy,tfault,tod,busy,done,ffault,clip,tr,trv,sr,srv,init,mfault,cke,oe,td,sout,clast,slast,sfault,spending,sowners,cmd,bank,addr,dqm,dout,level};
endmodule
