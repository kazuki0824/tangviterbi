module top(input wire core_clk,mem_clk,resetn,output wire activity);
reg[255:0] stimulus=256'h8128643212344321;
always @(posedge mem_clk)if(!resetn)stimulus<=256'h8128643212344321;
else stimulus<={stimulus[254:0],stimulus[255]^stimulus[253]^stimulus[250]^stimulus[245]};
wire ready,ir,ov,last,settled,result,done,busy,fault,qv,qw,sr;
wire[31:0] od;wire[20:0] qa;wire[255:0] qd;wire[31:0] qm;
dual_t_time_dma #(.MODE(1),.I0(4),.I1(8),.I2(16)) t(mem_clk,resetn,stimulus[0],ready,stimulus[1],stimulus[2],ir,stimulus[34:3],
ov,stimulus[11],od,last,settled,result,done,busy,fault,qv,stimulus[12],qw,qa,qd,qm,stimulus[13],sr,stimulus);
assign activity=^{ready,ir,ov,last,settled,result,done,busy,fault,qv,qw,sr,od,qa,qd,qm};
endmodule
