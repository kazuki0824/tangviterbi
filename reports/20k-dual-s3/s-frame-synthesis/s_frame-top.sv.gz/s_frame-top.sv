module top(input wire core_clk,mem_clk,resetn,output wire activity);
reg[255:0] stimulus=256'h8128643212344321;
always @(posedge mem_clk)if(!resetn)stimulus<=256'h8128643212344321;
else stimulus<={stimulus[254:0],stimulus[255]^stimulus[253]^stimulus[250]^stimulus[245]};
wire ir,ov,clast,slast,qv,qw,sr,fault;wire[7:0] od;wire[20:0] qa;wire[255:0] qd;wire[31:0] qm;wire[1:0] pending;wire[3:0] owners;
dual_s_frame_dma s(mem_clk,resetn,stimulus[0],ir,stimulus[8:1],ov,stimulus[9],od,clast,slast,
qv,stimulus[10],qw,qa,qd,qm,stimulus[11],sr,stimulus,pending,owners,fault);
assign activity=^{ir,ov,clast,slast,qv,qw,sr,fault,od,qa,qd,qm,pending,owners};
endmodule
