module top(input wire core_clk,mem_clk,resetn,output wire activity);
reg[255:0] stimulus=256'h8128643212344321;
always @(posedge mem_clk)if(!resetn)stimulus<=256'h8128643212344321;
else stimulus<={stimulus[254:0],stimulus[255]^stimulus[253]^stimulus[250]^stimulus[245]};
wire vr,ir,ov,done,fault,qv,qr,qw,sr;wire[7:0] od;wire[20:0] qa;wire[255:0] qd;wire[31:0] qm;
dual_vector_exchange v(mem_clk,resetn,stimulus[0],vr,stimulus[23:1],stimulus[39:24],
stimulus[40],ir,stimulus[48:41],ov,stimulus[49],od,done,fault,
qv,stimulus[50],qw,qa,qd,qm,stimulus[51],sr,stimulus);
assign activity=^{vr,ir,ov,done,fault,qv,qw,sr,od,qa,qd,qm};
endmodule
