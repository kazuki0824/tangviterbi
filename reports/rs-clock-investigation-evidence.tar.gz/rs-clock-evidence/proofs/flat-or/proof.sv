module reference_mux (input [5:0] state, input [3:0] inv_bit, input inv_mode, input [4:0] forney_k, input [7:0] coefficient_y, feedback_y, lambda_operand, synd_operand, bpoly_operand, bpoly0, coef, discrepancy, bval, lambda_q, omega_q, omega15, error0, errornext, error_x_q, chien_x, omega_value, x2, output [31:0] selected);
    localparam ST_INPUT          = 6'd0;
    localparam ST_BM_INIT        = 6'd2;
    localparam ST_BM_START       = 6'd3;
    localparam ST_BM_DISC        = 6'd4;
    localparam ST_BM_CHECK       = 6'd5;
    localparam ST_INV_SQUARE     = 6'd6;
    localparam ST_INV_MUL        = 6'd7;
    localparam ST_BM_COEF        = 6'd8;
    localparam ST_BM_UPDATE      = 6'd9;
    localparam ST_BM_POST        = 6'd10;
    localparam ST_OMEGA_INIT     = 6'd11;
    localparam ST_OMEGA_ACC      = 6'd12;
    localparam ST_OMEGA_STORE    = 6'd13;
    localparam ST_CHIEN_INIT     = 6'd14;
    localparam ST_CHIEN_EVAL     = 6'd15;
    localparam ST_CHIEN_CHECK    = 6'd16;
    localparam ST_CHIEN_NEXT     = 6'd17;
    localparam ST_FORNEY_INIT    = 6'd18;
    localparam ST_FORNEY_OMEGA   = 6'd19;
    localparam ST_FORNEY_X2      = 6'd20;
    localparam ST_FORNEY_D0      = 6'd21;
    localparam ST_FORNEY_D1      = 6'd22;
    localparam ST_FORNEY_D2      = 6'd23;
    localparam ST_FORNEY_MAG     = 6'd24;
    localparam ST_FORNEY_READ    = 6'd25;
    localparam ST_FORNEY_WRITE   = 6'd26;
    localparam ST_OUTPUT         = 6'd27;
    localparam ST_BLOCK_RESET    = 6'd28;
function automatic inv_exponent_bit; input [3:0] bit_index; begin inv_exponent_bit = (bit_index != 0); end endfunction
reg [7:0] coefficient_next_a, coefficient_next_b, feedback_next_a, feedback_next_b;
    always @* begin
        coefficient_next_a = 0; coefficient_next_b = 0;
        feedback_next_a = 0; feedback_next_b = 0;
        case (state)
            ST_BM_START, ST_BM_DISC, ST_OMEGA_INIT, ST_OMEGA_ACC, ST_OMEGA_STORE: begin
                coefficient_next_a = lambda_operand; coefficient_next_b = synd_operand;
            end
            ST_BM_COEF: begin
                coefficient_next_a = coefficient_y; coefficient_next_b = bpoly0;
            end
            ST_BM_UPDATE: begin
                coefficient_next_a = coef; coefficient_next_b = bpoly_operand;
            end
            ST_INV_SQUARE: begin
                if (!inv_exponent_bit(inv_bit) && !inv_mode) begin
                    coefficient_next_a = discrepancy; coefficient_next_b = feedback_y;
                end
            end
            default: begin end
        endcase
        case (state)
            ST_BM_CHECK, ST_FORNEY_D2: begin
                feedback_next_a = 1; feedback_next_b = 1;
            end
            ST_INV_SQUARE: begin
                if (inv_exponent_bit(inv_bit)) begin
                    feedback_next_a = feedback_y; feedback_next_b = bval;
                end else if (inv_mode) begin
                    feedback_next_a = omega_value; feedback_next_b = feedback_y;
                end
            end
            ST_INV_MUL: begin
                feedback_next_a = feedback_y; feedback_next_b = feedback_y;
            end
            ST_CHIEN_INIT: begin
                feedback_next_a = lambda_q; feedback_next_b = 1;
            end
            ST_CHIEN_EVAL: begin
                feedback_next_a = feedback_y ^ lambda_q; feedback_next_b = chien_x;
            end
            ST_CHIEN_CHECK: begin
                feedback_next_a = chien_x; feedback_next_b = 8'h02;
            end
            ST_CHIEN_NEXT: begin
                feedback_next_a = lambda_q; feedback_next_b = feedback_y;
            end
            ST_FORNEY_INIT: begin
                feedback_next_a = omega15; feedback_next_b = error0;
            end
            ST_FORNEY_OMEGA: begin
                if (forney_k == 0) begin
                    feedback_next_a = error_x_q; feedback_next_b = error_x_q;
                end else begin
                    feedback_next_a = feedback_y ^ omega_q; feedback_next_b = error_x_q;
                end
            end
            ST_FORNEY_X2: begin
                feedback_next_a = lambda_q; feedback_next_b = feedback_y;
            end
            ST_FORNEY_D0, ST_FORNEY_D1: begin
                feedback_next_a = feedback_y ^ lambda_q; feedback_next_b = x2;
            end
            ST_FORNEY_WRITE: begin
                feedback_next_a = omega15; feedback_next_b = errornext;
            end
            default: begin end
        endcase
    end

assign selected = {coefficient_next_a, coefficient_next_b, feedback_next_a, feedback_next_b};
endmodule
module candidate_mux (input [5:0] state, input [3:0] inv_bit, input inv_mode, input [4:0] forney_k, input [7:0] coefficient_y, feedback_y, lambda_operand, synd_operand, bpoly_operand, bpoly0, coef, discrepancy, bval, lambda_q, omega_q, omega15, error0, errornext, error_x_q, chien_x, omega_value, x2, output [31:0] selected);
    localparam ST_INPUT          = 6'd0;
    localparam ST_BM_INIT        = 6'd2;
    localparam ST_BM_START       = 6'd3;
    localparam ST_BM_DISC        = 6'd4;
    localparam ST_BM_CHECK       = 6'd5;
    localparam ST_INV_SQUARE     = 6'd6;
    localparam ST_INV_MUL        = 6'd7;
    localparam ST_BM_COEF        = 6'd8;
    localparam ST_BM_UPDATE      = 6'd9;
    localparam ST_BM_POST        = 6'd10;
    localparam ST_OMEGA_INIT     = 6'd11;
    localparam ST_OMEGA_ACC      = 6'd12;
    localparam ST_OMEGA_STORE    = 6'd13;
    localparam ST_CHIEN_INIT     = 6'd14;
    localparam ST_CHIEN_EVAL     = 6'd15;
    localparam ST_CHIEN_CHECK    = 6'd16;
    localparam ST_CHIEN_NEXT     = 6'd17;
    localparam ST_FORNEY_INIT    = 6'd18;
    localparam ST_FORNEY_OMEGA   = 6'd19;
    localparam ST_FORNEY_X2      = 6'd20;
    localparam ST_FORNEY_D0      = 6'd21;
    localparam ST_FORNEY_D1      = 6'd22;
    localparam ST_FORNEY_D2      = 6'd23;
    localparam ST_FORNEY_MAG     = 6'd24;
    localparam ST_FORNEY_READ    = 6'd25;
    localparam ST_FORNEY_WRITE   = 6'd26;
    localparam ST_OUTPUT         = 6'd27;
    localparam ST_BLOCK_RESET    = 6'd28;
function automatic inv_exponent_bit; input [3:0] bit_index; begin inv_exponent_bit = (bit_index != 0); end endfunction
reg [7:0] coefficient_next_a, coefficient_next_b, feedback_next_a, feedback_next_b;
    wire use_coefficient_arrays = (state == ST_BM_START) || (state == ST_BM_DISC) ||
        (state == ST_OMEGA_INIT) || (state == ST_OMEGA_ACC) || (state == ST_OMEGA_STORE);
    wire square_multiply = (state == ST_INV_SQUARE) && inv_exponent_bit(inv_bit);
    wire square_finish = (state == ST_INV_SQUARE) && !inv_exponent_bit(inv_bit);
    wire horner_omega = (state == ST_FORNEY_OMEGA) && (forney_k != 0);
    wire start_inverse = (state == ST_BM_CHECK) || (state == ST_FORNEY_D2);
    wire horner_lambda = (state == ST_CHIEN_EVAL) ||
        (state == ST_FORNEY_D0) || (state == ST_FORNEY_D1);

    // Gate each source locally before merging disjoint operations with OR.
    // Horner feedback uses XOR to combine its two active terms.
    // Operand registers, GF arithmetic and FSM cycle counts stay unchanged.
    always @* begin
        coefficient_next_a = (lambda_operand & {8{use_coefficient_arrays}}) |
            (coefficient_y & {8{state == ST_BM_COEF}}) |
            (coef & {8{state == ST_BM_UPDATE}}) |
            (discrepancy & {8{square_finish && !inv_mode}});
        coefficient_next_b = (synd_operand & {8{use_coefficient_arrays}}) |
            (bpoly0 & {8{state == ST_BM_COEF}}) |
            (bpoly_operand & {8{state == ST_BM_UPDATE}}) |
            (feedback_y & {8{square_finish && !inv_mode}});
        feedback_next_a = (feedback_y & {8{square_multiply ||
                (state == ST_INV_MUL) || horner_lambda || horner_omega}}) ^
            (lambda_q & {8{horner_lambda || (state == ST_CHIEN_INIT) ||
                (state == ST_CHIEN_NEXT) || (state == ST_FORNEY_X2)}}) ^
            (omega_q & {8{horner_omega}}) ^
            (omega15 & {8{(state == ST_FORNEY_INIT) || (state == ST_FORNEY_WRITE)}}) ^
            (error_x_q & {8{(state == ST_FORNEY_OMEGA) && (forney_k == 0)}}) ^
            (chien_x & {8{state == ST_CHIEN_CHECK}}) ^
            (omega_value & {8{square_finish && inv_mode}}) ^
            {7'd0, start_inverse};
        feedback_next_b = (bval & {8{square_multiply}}) |
            (feedback_y & {8{(square_finish && inv_mode) ||
                (state == ST_INV_MUL) || (state == ST_CHIEN_NEXT) || (state == ST_FORNEY_X2)}}) |
            (chien_x & {8{state == ST_CHIEN_EVAL}}) |
            (error0 & {8{state == ST_FORNEY_INIT}}) |
            (errornext & {8{state == ST_FORNEY_WRITE}}) |
            (error_x_q & {8{state == ST_FORNEY_OMEGA}}) |
            (x2 & {8{(state == ST_FORNEY_D0) || (state == ST_FORNEY_D1)}}) |
            {6'd0, (state == ST_CHIEN_CHECK), (start_inverse || (state == ST_CHIEN_INIT))};
    end

assign selected = {coefficient_next_a, coefficient_next_b, feedback_next_a, feedback_next_b};
endmodule
module proof(input [5:0] state, input [3:0] inv_bit, input inv_mode, input [4:0] forney_k, input [7:0] coefficient_y, feedback_y, lambda_operand, synd_operand, bpoly_operand, bpoly0, coef, discrepancy, bval, lambda_q, omega_q, omega15, error0, errornext, error_x_q, chien_x, omega_value, x2, output ok);
wire [31:0] ref_data,new_data;
reference_mux reference_dut(state, inv_bit, inv_mode, forney_k, coefficient_y, feedback_y, lambda_operand, synd_operand, bpoly_operand, bpoly0, coef, discrepancy, bval, lambda_q, omega_q, omega15, error0, errornext, error_x_q, chien_x, omega_value, x2,ref_data);
candidate_mux candidate_dut(state, inv_bit, inv_mode, forney_k, coefficient_y, feedback_y, lambda_operand, synd_operand, bpoly_operand, bpoly0, coef, discrepancy, bval, lambda_q, omega_q, omega15, error0, errornext, error_x_q, chien_x, omega_value, x2,new_data);
assign ok = ref_data == new_data;
endmodule
