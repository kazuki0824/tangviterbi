from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import subprocess

import argparse
p=argparse.ArgumentParser()
p.add_argument('root',type=Path)
p.add_argument('--seeds',default='2,3,4,5,6,7,8,9,10')
a=p.parse_args()
root=a.root
env = dict(os.environ, PATH='/tmp/oss-cad-suite/bin:' + os.environ['PATH'])

def run(item):
    variant, seed = item
    src = root / f'{variant}-110-seed1'
    dest = root / 'sweep-110' / variant / f'seed{seed}'
    dest.mkdir(parents=True, exist_ok=True)
    command = ['nextpnr-himbaechel', '--json', str(src / 'build/design.json'),
               '--device', 'GW1NR-LV9QN88PC6/I5', '--vopt', 'family=GW1N-9C',
               '--vopt', 'cst=' + str(src / 'constraints/tangnano9k.cst'),
               '--freq', '110', '--seed', str(seed), '--report', str(dest / 'report.json')]
    with (dest / 'pnr.log').open('w') as output:
        try:
            rc = subprocess.run(command, cwd=src, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=900).returncode
        except subprocess.TimeoutExpired:
            rc = 124
    log = (dest / 'pnr.log').read_text()
    routed = log.partition('Routing complete')[2]
    clocks = re.findall(r"Max frequency for clock '[^']+': ([\d.]+) MHz", routed)
    result = {'variant': variant, 'seed': seed, 'target_mhz': 110, 'exit_code': rc,
              'timeout': rc == 124, 'routing_completed': bool(routed),
              'fmax_mhz': min(map(float, clocks)) if clocks else None,
              'netlist_sha256': hashlib.sha256((src / 'build/design.json').read_bytes()).hexdigest(),
              'packed_utilization': {k: int(n) for k, n in re.findall(r'Info:\s+(LUT4|DFF|BSRAM|MULT18X18):\s+(\d+)/', log)}}
    (dest / 'measurement.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

items = [(variant, seed) for seed in tuple(map(int,a.seeds.split(',')))
         for variant in ('core-32acs-rsconst', 'mem-32acs-rsconst')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, items))
(root / 'sweep-110/results.json').write_text(json.dumps(results, indent=2) + '\n')
