from pathlib import Path
import concurrent.futures,json,os,re,subprocess,time,hashlib
root=Path('/tmp/tang-pr3-survivor-byte');out=Path('/tmp/tang-pr3-pnr-tuning')
env=dict(os.environ,PATH='/tmp/oss-cad-suite/bin:'+os.environ['PATH'])
trials={'weight20':['--placer-heap-timingweight','20'], 'weight40':['--placer-heap-timingweight','40'], 'router2-timing':['--router','router2','--tmg-ripup']}
def run(item):
 profile,variant=item;src=root/f'{variant}-65-seed1';dest=out/profile/variant;dest.mkdir(parents=True,exist_ok=True)
 cmd=['nextpnr-himbaechel','--json',str(src/'build/design.json'),'--device','GW1NR-LV9QN88PC6/I5','--vopt','family=GW1N-9C','--vopt','cst='+str(src/'constraints/tangnano9k.cst'),'--freq','110','--seed','1','--report',str(dest/'report.json'),*trials[profile]]
 with (dest/'pnr.log').open('w') as f:
  try:rc=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900).returncode
  except subprocess.TimeoutExpired:rc=124
 log=(dest/'pnr.log').read_text();routed=log.partition('Routing complete')[2];clocks=re.findall(r"Max frequency for clock '[^']+': ([\d.]+) MHz",routed)
 result={'profile':profile,'variant':variant,'seed':1,'target_mhz':110,'command':cmd,'exit_code':rc,'routing_completed':bool(routed),'timeout':rc==124,'fmax_mhz':min(map(float,clocks)) if clocks else None,'netlist_sha256':hashlib.sha256((src/'build/design.json').read_bytes()).hexdigest(),'packed_utilization':{k:int(n) for k,n in re.findall(r'Info:\s+(LUT4|DFF|BSRAM|MULT18X18):\s+(\d+)/',log)}}
 (dest/'measurement.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p: results=list(p.map(run,[(t,v) for t in trials for v in ('core-32acs-rsconst','mem-32acs-rsconst')]))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
