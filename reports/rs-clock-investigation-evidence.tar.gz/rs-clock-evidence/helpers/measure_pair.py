from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import subprocess

p = argparse.ArgumentParser()
p.add_argument('snapshot', type=Path)
p.add_argument('--freq', type=float, default=65)
p.add_argument('--seed', type=int, default=4)
a = p.parse_args()
env = dict(os.environ, PATH='/tmp/oss-cad-suite/bin:' + os.environ['PATH'])

def run(variant):
    dest = a.snapshot / f'{variant}-{a.freq:g}-seed{a.seed}'
    dest.mkdir(exist_ok=True)
    for folder in ('rtl', 'ci', 'constraints', 'experiments'):
        shutil.copytree(a.snapshot / folder, dest / folder, dirs_exist_ok=True)
    cmd = ['bash', 'ci/run_pnr.sh', '9k', variant, '--freq', str(a.freq), '--seed', str(a.seed)]
    with (dest / 'trial.log').open('w') as output:
        try:
            rc = subprocess.run(cmd, cwd=dest, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=900).returncode
        except subprocess.TimeoutExpired:
            rc = 124
    log = (dest / 'build/pnr.log').read_text() if (dest / 'build/pnr.log').exists() else ''
    routed = log.partition('Routing complete')[2]
    clocks = re.findall(r"Max frequency for clock '[^']+': ([\d.]+) MHz", routed)
    counts = {k: int(n) for k, n in re.findall(r'Info:\s+(LUT4|DFF|BSRAM|MULT18X18):\s+(\d+)/', log)}
    result = {'variant': variant, 'target_mhz': a.freq, 'seed': a.seed,
              'exit_code': rc, 'routing_completed': bool(routed),
              'fmax_mhz': min(map(float, clocks)) if clocks else None,
              'packed_utilization': counts, 'timeout': rc == 124,
              'viterbi32_sha256': hashlib.sha256((dest / 'rtl/viterbi_k7_32acs.sv').read_bytes()).hexdigest(),
              'viterbi16_sha256': hashlib.sha256((dest / 'rtl/viterbi_k7_16acs.sv').read_bytes()).hexdigest()}
    (dest / 'measurement.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, ('core-32acs-rsconst', 'mem-32acs-rsconst')))
(a.snapshot / f'results-{a.freq:g}-seed{a.seed}.json').write_text(json.dumps(results, indent=2) + '\n')
