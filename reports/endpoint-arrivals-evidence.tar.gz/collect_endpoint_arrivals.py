from collections import Counter
from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

repo = Path('/workspace/scratch/49bbc86dda7a/tangviterbi-9k-pr3')
raw = Path('/tmp/pr3-full-detailed-timing')
baseline = Path('/tmp/tang-pr3-survivor-byte')
stage = Path('/tmp/pr3-endpoint-arrival-evidence')
stage.mkdir(exist_ok=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

results = []
for variant in ('core-32acs-rsconst', 'mem-32acs-rsconst'):
    root = raw / variant
    old = baseline / f'{variant}-65-seed1' / 'build'
    report = json.loads((root / 'report.json').read_text())
    measurement = json.loads((root / 'measurement.json').read_text())
    checksums = re.findall(r'Checksum: 0x([0-9a-f]+)', (root / 'pnr.log').read_text())
    prior_checksums = re.findall(r'Checksum: 0x([0-9a-f]+)', (old / 'pnr.log').read_text())
    assert checksums == prior_checksums and len(checksums) == 3
    assert measurement['routing_completed'] and measurement['exit_code'] == 1
    assert sha(old / 'design.json') == measurement['netlist_sha256']
    recorded_report = repo / 'reports/survivor-prefetch' / f"{variant.split('-')[0]}-110-seed1.report.json"
    prior_report = json.loads(recorded_report.read_text())
    for key in ('fmax', 'critical_paths', 'utilization'):
        assert report[key] == prior_report[key], key
    routed = json.loads((old / 'routed.json').read_text())['modules']['top']
    rows = []
    for net in report['detailed_net_timings']:
        for endpoint in net['endpoints']:
            cell = routed['cells'][endpoint['cell']]
            driver = routed['cells'][net['driver']]
            bel = cell['attributes']['NEXTPNR_BEL']
            driver_bel = driver['attributes']['NEXTPNR_BEL']
            group = 'rs' if endpoint['cell'].startswith('g_rs.') else 'viterbi' if endpoint['cell'].startswith('g_viterbi.') else 'other'
            rows.append({
                'arrival_min_ns': endpoint['delay'][0],
                'arrival_max_ns': endpoint['delay'][1],
                'cell': endpoint['cell'], 'port': endpoint['port'],
                'cell_type': cell['type'], 'bel': bel,
                'group_by_name': group,
                'net': net['net'], 'driver': net['driver'],
                'driver_port': net['port'], 'driver_bel': driver_bel,
                'launch_event': net['event'], 'capture_event': endpoint['event'],
            })
    rows.sort(key=lambda x: (-x['arrival_max_ns'], x['cell'], x['port']))
    assert all(r['launch_event'] == r['capture_event'] for r in rows)
    cp = report['critical_paths'][0]['path']
    total = sum(p['delay'] for p in cp)
    fmax = min(c['achieved'] for c in report['fmax'].values())
    assert abs(total - 1000 / fmax) < 0.001
    bands = []
    for threshold in (9.0, 8.5, 8.0):
        selected = [r for r in rows if r['arrival_max_ns'] >= threshold]
        bands.append({'min_raw_arrival_ns': threshold, 'endpoint_count': len(selected),
                      'groups_by_name': dict(Counter(r['group_by_name'] for r in selected)),
                      'ports': dict(Counter(r['port'] for r in selected))})
    multi_nets = []
    for net in report['detailed_net_timings']:
        selected = [e for e in net['endpoints'] if e['delay'][1] >= 9.0]
        if len(selected) > 1:
            multi_nets.append({'net': net['net'], 'driver': net['driver'],
                               'driver_bel': routed['cells'][net['driver']]['attributes']['NEXTPNR_BEL'],
                               'endpoint_count_at_or_above_9ns': len(selected),
                               'ports': dict(Counter(e['port'] for e in selected))})
    dest = stage / variant
    dest.mkdir(exist_ok=True)
    for name in ('pnr.log', 'report.json', 'measurement.json'):
        shutil.copy2(root / name, dest / name)
    (dest / 'mapped-endpoint-arrivals.json').write_text(json.dumps(rows, indent=2) + '\n')
    results.append({
        'variant': variant, 'routed_fmax_mhz': measurement['fmax_mhz'],
        'critical_period_ns': total, 'required_110mhz_period_ns': 1000/110,
        'critical_period_reduction_needed_ns': total - 1000/110,
        'routing_completed': True, 'exit_code': 1,
        'checksums_pack_place_route': checksums,
        'identical_recorded_110mhz_fields': ['fmax', 'critical_paths', 'utilization'],
        'recorded_baseline_report': str(recorded_report.relative_to(repo)),
        'timed_nets': len(report['detailed_net_timings']), 'endpoint_entries': len(rows),
        'arrival_bands': bands, 'top_20_raw_arrivals': rows[:20],
        'highest_viterbi_raw_arrival': next(r for r in rows if r['group_by_name'] == 'viterbi'),
        'multi_endpoint_nets_at_or_above_9ns': multi_nets,
        'netlist_sha256': measurement['netlist_sha256'],
        'baseline_routed_json_sha256': sha(old / 'routed.json'),
        'detailed_report_sha256': sha(root / 'report.json'),
        'pnr_log_sha256': sha(root / 'pnr.log'),
        'command': measurement['command'],
    })

data = {
    'hardware_baseline_commit': '754c111695dc64651466e729155846fcc08d2bbb',
    'parent_commit': '3d3512b201aa6e52b502414b936544394d9a0c3b',
    'tool_suite': 'OSS CAD Suite 2026-10-04',
    'nextpnr_commit': 'e2fe86b3', 'device': 'GW1NR-LV9QN88PC6/I5',
    'family': 'GW1N-9C', 'seed': 1, 'target_mhz': 110,
    'cst_sha256': sha(repo / 'constraints/tangnano9k.cst'),
    'scope': 'Diagnostic output only; no RTL, performance profile or P&R settings changed.',
    'arrival_semantics': 'The detailed JSON delay range is the endpoint arrival range, not setup slack or a full path period. Do not count threshold selections as timing violations. Full critical-path periods and Fmax use the normal critical_paths/fmax fields.',
    'location_provenance': 'NEXTPNR_BEL from the prior seed-1 routed JSON. The new full P&R has identical packing/placement/routing checksums and identical complete critical_paths/fmax/utilization fields. Every endpoint and driver maps to a cell in that routed JSON.',
    'variants': results,
}
summary = repo / 'reports/endpoint-arrivals.json'
summary.write_text(json.dumps(data, indent=2) + '\n')
shutil.copy2(summary, stage / 'summary.json')
shutil.copy2(Path(__file__), stage / 'collect_endpoint_arrivals.py')
archive = repo / 'reports/endpoint-arrivals-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(stage.rglob('*')):
        if path.is_file():
            tar.add(path, arcname=str(path.relative_to(stage)))
with tarfile.open(archive) as tar:
    stored = json.load(tar.extractfile('summary.json'))
    assert stored == data
    for result in results:
        path = f"{result['variant']}/report.json"
        assert hashlib.sha256(tar.extractfile(path).read()).hexdigest() == result['detailed_report_sha256']
print(json.dumps({'archive_bytes': archive.stat().st_size, 'summary_bytes': summary.stat().st_size,
                  'variants': [{k:r[k] for k in ('variant', 'routed_fmax_mhz', 'timed_nets', 'endpoint_entries', 'arrival_bands')} for r in results]}, indent=2))
