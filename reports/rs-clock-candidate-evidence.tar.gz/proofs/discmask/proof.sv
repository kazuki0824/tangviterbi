module proof(input [5:0] state, input [4:0] bm_n, input [7:0] discrepancy, input [15:0] mask, input [127:0] syndrome, output ok);
wire init = state == 2;
wire advance = ((state == 5) && (discrepancy == 0) && (bm_n != 15)) || ((state == 10) && (bm_n != 15));
wire [4:0] next_n = init ? 5'd0 : advance ? bm_n + 5'd1 : bm_n;
wire [15:0] next_mask = init ? 16'd1 : advance ? mask << 1 : mask;
wire valid = (bm_n < 16) && (mask == (16'd1 << bm_n));
reg [7:0] selected;integer i;
always @* begin selected=0;for(i=0;i<16;i=i+1)selected=selected | (syndrome[8*i+:8] & {8{mask[i]}});end
assign ok = !valid || ((next_mask == (16'd1 << next_n)) && (next_n < 16) && (selected == syndrome[8*bm_n+:8]));
endmodule
