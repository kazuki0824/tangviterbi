module proof(input [7:0] out_index, input out_primed, output ok);
wire [7:0] old_addr=out_primed ? out_index+8'd1 : out_index;
wire [7:0] output_read_address;
assign output_read_address[0]=out_index[0]^out_primed;
genvar address_bit;generate for(address_bit=1;address_bit<8;address_bit=address_bit+1)begin:g_output_address
assign output_read_address[address_bit]=out_index[address_bit]^(out_primed&&(&out_index[address_bit-1:0]));
end endgenerate
assign ok=old_addr==output_read_address;endmodule
