module proof(input [31:0] lo, hi, input [5:0] capture_state, consume_state, output ok);
wire [7:0] lo_byte=lo[{capture_state[4:3],3'b0}+:8];
wire [7:0] hi_byte=hi[{capture_state[4:3],3'b0}+:8];
wire [7:0] old_byte=capture_state[5] ? hi_byte : lo_byte;
wire [7:0] new_byte=consume_state[5] ? hi_byte : lo_byte;
assign ok=(capture_state[5]!=consume_state[5]) || (old_byte[consume_state[2:0]]==new_byte[consume_state[2:0]]);
endmodule
