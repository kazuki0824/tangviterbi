module proof(input resetn, input [5:0] state, input [4:0] n5, input [3:0] n4, input [7:0] discrepancy, output ok);
wire init=state==2;
wire advance=((state==5)&&(discrepancy==0)&&(n5!=15))||((state==10)&&(n5!=15));
wire [4:0] next5=!resetn ? 0 : init ? 0 : advance ? n5+5'd1 : n5;
wire [3:0] next4=!resetn ? 0 : init ? 0 : advance ? n4+5'd1 : n4;
wire invariant=(n5<16)&&(n4==n5);
assign ok=!invariant || ((next5<16)&&(next4==next5));
endmodule
