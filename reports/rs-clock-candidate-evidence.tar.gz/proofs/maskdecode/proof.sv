module proof(input [3:0] m, input [4:0] n, output ok);
    function automatic [8:0] decode_lambda;
        input [3:0] index;
        integer bit_index;
        begin
            for (bit_index = 0; bit_index < 9; bit_index = bit_index + 1)
                decode_lambda[bit_index] = (index == bit_index);
        end
    endfunction
    function automatic [15:0] decode_syndrome;
        input [4:0] index;
        integer bit_index;
        begin
            for (bit_index = 0; bit_index < 16; bit_index = bit_index + 1)
                decode_syndrome[bit_index] = (index == bit_index);
        end
    endfunction


assign ok = (decode_lambda(m) == (9'd1 << m)) &&
            (decode_syndrome(n) == (16'd1 << n)) &&
            (decode_syndrome(n + 5'd1) == (16'd1 << (n + 5'd1)));
endmodule
