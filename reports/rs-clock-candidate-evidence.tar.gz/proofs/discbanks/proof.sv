module proof(input [5:0] previous_state, input [4:0] previous_n, input [7:0] discrepancy, input [127:0] syndrome, output ok);
wire init = previous_state == 2;
wire advance = (((previous_state == 5) && (discrepancy == 0)) || (previous_state == 10)) && (previous_n < 15);
wire enters_start = init || advance;
wire [4:0] current_n = init ? 0 : previous_n + 5'd1;
wire [1:0] prefetch_index = init ? 0 : previous_n[1:0] + 2'd1;
wire [7:0] q0=syndrome[8*{2'd0,prefetch_index}+:8];
wire [7:0] q1=syndrome[8*{2'd1,prefetch_index}+:8];
wire [7:0] q2=syndrome[8*{2'd2,prefetch_index}+:8];
wire [7:0] q3=syndrome[8*{2'd3,prefetch_index}+:8];
wire [31:0] banks={q3,q2,q1,q0};
wire [7:0] selected=banks[8*current_n[3:2]+:8];
assign ok = !enters_start || (selected == syndrome[8*current_n+:8]);
endmodule
